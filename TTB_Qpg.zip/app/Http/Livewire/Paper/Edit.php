<?php

namespace App\Http\Livewire\Paper;

use Livewire\Component;

class Edit extends Component
{
    public function render()
    {
        return view('livewire.paper.edit');
    }
}
