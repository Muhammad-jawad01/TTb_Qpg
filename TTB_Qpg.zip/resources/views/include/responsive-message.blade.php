<div class="responsive-msg-component">
    <p>
        <a class="close-msg-component"><i class="las la-times"></i></a>
        {{__('Please reload the page to view the responsive functionalities')}}
    </p>
</div>
