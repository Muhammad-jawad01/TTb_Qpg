<!-- Copyright Footer Starts -->
<div class="footer-wrapper">
    <div class="footer-section f-section-1">
        <p class=""> {{ __('Copyright © ' . date('Y') . ' Question paper Generator. All rights reserved.') }} </p>

    </div>
    <div class="footer-section f-section-2">

    </div>
</div>
<!-- Copyright Footer Ends -->
