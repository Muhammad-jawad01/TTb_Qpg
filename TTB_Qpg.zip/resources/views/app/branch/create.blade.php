@extends('layout.master')

@section('title', 'Create Branch')


@section('content')
    <livewire:branch.form />
@endsection
