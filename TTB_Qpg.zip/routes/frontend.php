<?php

// Route::get('/', function () {
//     return view('dashboard.dashboard1');
// });
// Route::get('/', function () {
//     return view('app.welcome');
// });
 Route::redirect('/', 'login');